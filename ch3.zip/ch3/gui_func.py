'''
Color
primary
secondary
success
info
warning
danger
light
dark
white
black
gray
red
orange
yellow
green
teal
cyan
blue
indigo
purple
pink
'''

from PIL import Image, ImageTk



def split_vertical(ttk, window, top_height):
    """
    指定したウィンドウ領域を、引数の高さで上下に分割し、分割した領域を返す。

    Args:
        ttk (module): ttkbootstrapモジュール
        window (ttk.Window): ウィンドウオブジェクト
        top_height (int): 上部領域の高さ

    Returns:
        tuple: (top_frame, bottom_frame) の領域
    """
    # ウィンドウの現在の幅と高さを取得
    window.update_idletasks()  # ウィンドウのサイズ情報を最新に更新
    window_width = window.winfo_width()
    window_height = window.winfo_height()

    # 上部の領域を作成
    top_frame = ttk.Frame(window, bootstyle="primary", height=top_height, width=window_width)
    top_frame.place(x=0, y=0, width=window_width, height=top_height)

    # 下部の領域を作成
    bottom_frame = ttk.Frame(window, bootstyle="secondary", height=window_height - top_height, width=window_width)
    bottom_frame.place(x=0, y=top_height, width=window_width, height=window_height - top_height)

    # 2つの領域をタプルで返す
    return top_frame, bottom_frame



def split_horizontal(ttk, window, left_width):
    """
    指定したウィンドウ領域を、引数の幅で左右に分割し、分割した領域を返す。

    Args:
        ttk (module): ttkbootstrapモジュール
        window (ttk.Window): ウィンドウオブジェクト
        left_width (int): 左側領域の幅

    Returns:
        tuple: (left_frame, right_frame) の領域
    """
    # ウィンドウの現在の幅と高さを取得
    window.update_idletasks()  # ウィンドウのサイズ情報を最新に更新
    window_width = window.winfo_width()
    window_height = window.winfo_height()

    # 左側の領域を作成
    left_frame = ttk.Frame(window, bootstyle="primary", width=left_width, height=window_height)
    left_frame.place(x=0, y=0, width=left_width, height=window_height)

    # 右側の領域を作成
    right_frame = ttk.Frame(window, bootstyle="secondary", width=window_width - left_width, height=window_height)
    right_frame.place(x=left_width, y=0, width=window_width - left_width, height=window_height)

    return left_frame, right_frame


def set_background_color(ttk, frame, color_name):
    """
    指定した領域の背景色を変更し、その領域を返す。

    Args:
        ttk (module): ttkbootstrapモジュール
        frame (ttk.Frame): 色を変更したいフレーム
        color_name (str): 色の名前（例："red", "blue" など）

    Returns:
        ttk.Frame: 色が変更されたフレーム
    """
    # 指定された色で背景色を設定
    frame.configure(style=f"{color_name}.TFrame")
    
    # 色スタイルを定義
    style = ttk.Style()
    style.configure(f"{color_name}.TFrame", background=color_name)

    return frame




def set_background_image(ttk, frame, image_path):
    """
    指定した領域に画像を縦横比を保ちながら背景として設定し、その領域を返す。

    Args:
        ttk (module): ttkbootstrapモジュール
        frame (ttk.Frame): 画像を設定したいフレーム
        image_path (str): 画像のファイルパス

    Returns:
        ttk.Frame: 画像が設定されたフレーム
    """
    def set_image():
        # 画像を読み込み、フレームのサイズに合わせてリサイズ
        image = Image.open(image_path)
        frame_width, frame_height = frame.winfo_width(), frame.winfo_height()
        img_width, img_height = image.size

        # 縦横比を維持しながらリサイズ
        aspect_ratio = img_width / img_height
        if frame_width / frame_height > aspect_ratio:
            new_height = frame_height
            new_width = int(new_height * aspect_ratio)
        else:
            new_width = frame_width
            new_height = int(new_width / aspect_ratio)

        resized_image = image.resize((new_width, new_height), Image.LANCZOS)
        photo_image = ImageTk.PhotoImage(resized_image)

        # ラベルに画像をセットし、フレーム内の中央に配置
        background_label = ttk.Label(frame, image=photo_image)
        background_label.image = photo_image  # 参照を保持するために属性として保持
        background_label.place(x=(frame_width - new_width) // 2, y=(frame_height - new_height) // 2)

        # 参照をフレームの属性として保持
        frame.background_label = background_label
        frame.photo_image = photo_image  # フレームの属性としても参照を保持

    # afterメソッドで、サイズが確定した後に画像をセット
    frame.after(100, set_image)

    return frame


def create_centered_label(ttk, frame, width, height, text):
    """
    指定した領域の中央に、指定された幅と高さで表示専用のテキストラベルを作成し、返します。

    Args:
        ttk (module): ttkbootstrapモジュール
        frame (ttk.Frame): 背景画像が設定されたフレーム
        width (int): ラベル領域の幅
        height (int): ラベル領域の高さ
        text (str): 表示するテキスト

    Returns:
        ttk.Label: 作成された表示専用のテキストラベル
    """
    # フレームのサイズを取得
    frame.update_idletasks()
    frame_width = frame.winfo_width()
    frame_height = frame.winfo_height()

    # ラベルの左上位置を計算して中央に配置
    x = (frame_width - width) // 2
    y = (frame_height - height) // 2

    # 表示専用のテキストラベルを作成し、背景を透明に設定
    label = ttk.Label(frame, text=text, anchor="center", wraplength=width)
    label.place(x=x, y=y, width=width, height=height)

    # ラベルを最前面に移動する処理を背景画像設定後に実行
    frame.after(200, label.lift)  # 画像設定後に再度ラベルを最前面に

    return label

def set_label_font(ttk, label, font_name="Meiryo", font_size=12, font_style="normal"):
    """
    指定されたラベルのフォントを変更し、変更後のラベルを返します。

    Args:
        ttk (module): ttkbootstrapモジュール
        label (ttk.Label): フォントを変更したいラベル
        font_name (str): フォントファミリ名（例："Meiryo"）
        font_size (int): フォントサイズ（デフォルト: 12）
        font_style (str): フォントスタイル（"normal", "bold", "italic"など）

    Returns:
        ttk.Label: フォントが変更されたラベル
    """
    # 新しいフォント設定
    new_font = (font_name, font_size, font_style)

    # ラベルに新しいフォントを設定
    label.configure(font=new_font)

    return label

def create_button_grid(ttk, window, n, m, padding=0):
    """
    ウィンドウ内にn行m列でボタンを配置し、それぞれのボタン要素をリストとして返します。

    Args:
        ttk (module): ttkbootstrapモジュール
        window (ttk.Window): ウィンドウオブジェクト
        n (int): ボタンの行数
        m (int): ボタンの列数
        padding (int): 各ボタン間のパディング（デフォルトは0）

    Returns:
        list: ボタン要素を格納したリスト（2次元リスト形式で返す）
    """
    button_grid = []  # ボタン要素を格納するリスト

    # ウィンドウのサイズを取得して、ボタンのサイズを計算
    window.update_idletasks()
    window_width = window.winfo_width()
    window_height = window.winfo_height()

    # パディング分を考慮してボタンのサイズを計算
    button_width = (window_width - (m + 1) * padding) // m
    button_height = (window_height - (n + 1) * padding) // n

    # ボタンをn行m列で配置
    for i in range(n):
        row_buttons = []
        for j in range(m):
            # 各ボタンのx, y位置を計算（パディングを考慮）
            x = j * (button_width + padding) + padding
            y = i * (button_height + padding) + padding

            # ボタンの作成と配置
            button = ttk.Button(window, text=f"Button {i+1}-{j+1}")
            button.place(x=x, y=y, width=button_width, height=button_height)
            row_buttons.append(button)
        button_grid.append(row_buttons)

    return button_grid

def set_button_color(ttk, button, color):
    """
    指定されたボタンの色を変更し、変更後のボタンを返します。

    Args:
        ttk (module): ttkbootstrapモジュール
        button (ttk.Button): 色を変更したいボタン
        color (str): 設定する色のスタイル（"primary", "secondary", "success", "warning", "danger"など）

    Returns:
        ttk.Button: 色が変更されたボタン
    """
    # 新しいスタイル名を設定
    style_name = f"{color}.TButton"
    
    # スタイルを定義
    style = ttk.Style()
    style.configure(style_name, bootstyle=color)
    
    # ボタンに新しいスタイルを適用
    button.configure(style=style_name)

    return button

def set_button_custom_color(ttk, button, color_code):
    """
    指定されたボタンの背景色をカスタム色コードで変更し、変更後のボタンを返します。

    Args:
        ttk (module): ttkbootstrapモジュール
        button (ttk.Button): 色を変更したいボタン
        color_code (str): 設定する色のコード（例: "#ff0000"）

    Returns:
        ttk.Button: 色が変更されたボタン
    """
    # 新しいスタイル名を設定
    style_name = f"{button.winfo_id()}.TButton"  # ボタンごとに固有のスタイル名を作成

    # スタイルを定義
    style = ttk.Style()
    style.configure(style_name, background=color_code)

    # ボタンに新しいスタイルを適用
    button.configure(style=style_name)

    return button

def set_button_text_style(ttk, button, font_name="Meiryo", font_size=12, text_color="#000000"):
    """
    指定されたボタンのテキストのフォント、文字色、フォントサイズを変更し、変更後のボタンを返します。

    Args:
        ttk (module): ttkbootstrapモジュール
        button (ttk.Button): スタイルを変更したいボタン
        font_name (str): 設定するフォント名（デフォルトは "Meiryo"）
        font_size (int): 設定するフォントサイズ（デフォルトは 12）
        text_color (str): 設定する文字色の16進数カラーコード（例: "#FF0000"）

    Returns:
        ttk.Button: スタイルが変更されたボタン
    """
    # ボタンごとに固有のスタイル名を作成
    style_name = f"{button.winfo_id()}.TButton"
    
    # スタイルを定義してテキストの文字色、フォントサイズ、フォント名を変更
    style = ttk.Style()
    style.configure(style_name, foreground=text_color, font=(font_name, font_size))

    # ボタンに新しいスタイルを適用
    button.configure(style=style_name)

    return button

def typewriter_effect(label, text, delay=50, callback=None):
    """
    ラベル要素にタイプライターのように1文字ずつテキストを表示し、
    完了後にコールバックを実行します。

    Args:
        label (ttk.Label): テキストを表示するラベル
        text (str): 表示するテキスト内容
        delay (int): 1文字ごとの表示の遅延時間（ミリ秒）
        callback (function): 表示完了後に実行する関数（オプション）
    """
    # ラベルを初期化
    label.config(text="")

    def display_next_char(index=0):
        if index <= len(text):
            label.config(text=text[:index])
            label.after(delay, display_next_char, index + 1)
        else:
            # 全ての文字が表示された後にコールバックを実行
            if callback:
                callback()

    # 表示を開始
    display_next_char()
