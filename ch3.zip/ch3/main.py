import ttkbootstrap as ttk
from ttkbootstrap.constants import *
from gui_func import *  # splitter.pyから関数をインポート
import colors 
import time

def main():
    # メインウィンドウの作成
    window = ttk.Window(themename="flatly")
    window.geometry("800x600")
    window.title("Vertical Split Window Example")

    # 分割関数を呼び出し、上部と下部の領域を取得
    header_frame, main_frame = split_vertical(ttk, window, 100)
    main_frame, footer_frame = split_vertical(ttk, main_frame, 400)
    left_frame, right_frame = split_horizontal(ttk, main_frame, 500)
    left_upper_frame, left_lower_frame = split_vertical(ttk, left_frame, 250)

    set_background_color(ttk, header_frame, "white")    
    set_background_color(ttk,footer_frame, "white")    
    set_background_color(ttk, right_frame, "white")
    set_background_color(ttk, left_upper_frame, "white")
    set_background_color(ttk, left_lower_frame, "white")
    
    set_background_image(ttk, right_frame, "./images/tsukuyomichan/prayer.png")
    set_background_image(ttk, left_upper_frame, "./images/fukidashi/fukidashi1.png")

    # テストとして分割領域にラベルを配置
    '''
    ttk.Label(header_frame, text="Top Area", bootstyle="inverse").pack(pady=10)
    ttk.Label(main_frame, text="Main Area", bootstyle="inverse").pack(pady=10)
    ttk.Label(right_frame, text="Right Area", bootstyle="inverse").pack(pady=10)
    ttk.Label(left_frame, text="Left Area", bootstyle="inverse").pack(pady=10)
    ttk.Label(left_upper_frame, text="Left Upper Area", bootstyle="inverse").pack(pady=10)
    ttk.Label(left_lower_frame, text="Left Lower Area", bootstyle="inverse").pack(pady=10)
    ttk.Label(footer_frame, text="Bottom Area", bootstyle="inverse").pack(pady=10)
    '''

    text = "This is a centered label.\nThis text is display-only.\npiyopiyo"
    label = create_centered_label(ttk, left_upper_frame, width=300, height=180, text=text)
    # set_background_color(ttk, label, "lightblue")
    label = set_label_font(ttk, label)
    label.configure(anchor="nw")
    label.lift()
    
    buttons = create_button_grid(ttk, left_lower_frame, n=1, m=2, padding=40)
    buttons[0][0].configure(text="実行する")
    buttons[0][1].configure(text="キャンセル")

    buttons[0][0] = set_button_custom_color(ttk, buttons[0][0], colors.LIGHT_GREEN)
    buttons[0][0] = set_button_text_style(ttk, buttons[0][0], font_size=18, text_color=colors.BLACK)
    buttons[0][0].configure(state="disabled")

    buttons[0][1] = set_button_custom_color(ttk, buttons[0][1], colors.YELLOW)
    buttons[0][1] = set_button_text_style(ttk, buttons[0][1], font_size=18, text_color=colors.BLACK)
    buttons[0][1].configure(state="disabled")
    
    def start_third_sequence():
        set_background_image(ttk, right_frame, "./images/tsukuyomichan/look_left.png")
        text2 = "円周率計算を開始しますか？"
        typewriter_effect(label, text2, delay=100)
        time.sleep(1)        
        buttons[0][0].configure(state="enabled")
        buttons[0][1].configure(state="enabled")
    
    def start_second_sequence():
        set_background_image(ttk, right_frame, "./images/tsukuyomichan/may_i_ask.png")
        text2 = "それでは\n作業を開始します。"
        typewriter_effect(label, text2, delay=100, callback=start_third_sequence)
        time.sleep(1)

    # 最初のテキストをタイプライター風に表示し、完了後に次の処理を実行
    text1 = "こんにちは。\nつくよみちゃんUIです。"
    typewriter_effect(label, text1, delay=100, callback=start_second_sequence)


    # ウィンドウを表示
    window.mainloop()

if __name__ == "__main__":
    main()
